# Shapes > 2026-10-06 8:25pm
https://universe.roboflow.com/imgml/shapes-uuheu

Provided by a Roboflow user
License: CC BY 4.0

